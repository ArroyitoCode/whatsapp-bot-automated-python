import pywhatkit as kit
import pyautogui
import datetime
import time

def enviar_mensaje(numero, mensaje):
    ahora = datetime.datetime.now()
    hora = ahora.hour
    minuto = ahora.minute + 2  # margen de tiempo

    print(f"\n📨 Programando mensaje para {numero} en {hora}:{minuto:02d}...")
    kit.sendwhatmsg(numero, mensaje, hora, minuto, wait_time=20)

    print("⏳ Esperando que WhatsApp Web cargue (no uses el mouse o teclado)...")
    time.sleep(30)

    print("🔘 Enviando mensaje automáticamente...")
    pyautogui.press("enter")
    print(f"✅ Mensaje enviado a {numero}\n")
    time.sleep(5)

def main():
    print("🤖 BOT DE WHATSAPP AUTOMÁTICO – MULTI ENVÍO\n")
    print("⚠️ Instrucciones:")
    print("- Ingresa números con código de país (+57 para Colombia)")
    print("- Al terminar, escribe: listo")
    print("- No muevas el mouse ni uses el teclado cuando WhatsApp esté cargando")

    contactos = []

    while True:
        numero = input("📲 Número de WhatsApp: ")
        if numero.lower() == "listo":
            break
        contactos.append(numero)

    if not contactos:
        print("⚠️ No ingresaste ningún número. Cerrando bot.")
        return

    mensaje = input("\n📝 Escribe el mensaje a enviar: ")

    print("\n🟢 Enviando mensaje a todos los contactos...\n")

    for numero in contactos:
        enviar_mensaje(numero, mensaje)

    print("🎉 Todos los mensajes han sido enviados correctamente.")

if __name__ == "__main__":
    main()
